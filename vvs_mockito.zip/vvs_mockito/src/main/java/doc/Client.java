package doc;

public interface Client {

	public Object getEmail();

}
