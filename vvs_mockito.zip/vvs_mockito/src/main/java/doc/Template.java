package doc;

public interface Template {

}
