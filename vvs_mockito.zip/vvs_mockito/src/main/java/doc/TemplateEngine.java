package doc;

public interface TemplateEngine {

	public String prepareMessage(Template template, Client client);

}
