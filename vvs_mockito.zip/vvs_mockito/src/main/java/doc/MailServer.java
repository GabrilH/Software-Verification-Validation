package doc;

public interface MailServer {

	public void send(Object email, String msgContent);

}
